/* tslint:disable */
require("./ZnaImageCarousel.module.css");
const styles = {
  znaImageCarousel: 'znaImageCarousel_33de2699',
  container: 'container_33de2699',
  row: 'row_33de2699',
  column: 'column_33de2699',
  'ms-Grid': 'ms-Grid_33de2699',
  title: 'title_33de2699',
  subTitle: 'subTitle_33de2699',
  description: 'description_33de2699',
  button: 'button_33de2699',
  label: 'label_33de2699'
};

export default styles;
/* tslint:enable */