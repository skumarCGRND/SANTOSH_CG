
import CustomPanel, { ICustomPanelProps } from  "../../components/CustomPanel"
import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseListViewCommandSet,
  Command,
  IListViewCommandSetListViewUpdatedParameters,
  IListViewCommandSetExecuteEventParameters
} from '@microsoft/sp-listview-extensibility';
import { Dialog } from '@microsoft/sp-dialog';

import * as strings from 'EflSpecimenCommandSetStrings';
import * as React from 'react';	
import * as ReactDom from 'react-dom';
import { sp } from "@pnp/sp";	
import { assign } from '@uifabric/utilities';




/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IEflSpecimenCommandSetProperties {
  // This is an example; replace with your own properties
  sampleTextOne: string;
  //sampleTextTwo: string;
}

const LOG_SOURCE: string = 'EflSpecimenCommandSet';

export default class EflSpecimenCommandSet extends BaseListViewCommandSet<IEflSpecimenCommandSetProperties> {

  // @override
  // public onInit(): Promise<void> {
  //   Log.info(LOG_SOURCE, 'Initialized EflSpecimenCommandSet');
  //   return Promise.resolve();
  // }
  // private _showPanel(itemId: number, currentTitle: string) {	   
  //    this._renderPanelComponent({	      
  //      isOpen: true,	      
  //      currentTitle,	      
  //      itemId,	      
  //      listId: this.context.pageContext.list.id.toString(),	    
  //        onClose: this._dismissPanel	  
  //    });	 
  //  }

  private _showPanel(itemId: any) {	   
    this._renderPanelComponent({	      
      isOpen: true,	      
      //currentTitle,	      
      itemId,	      
      listId: this.context.pageContext.list.id.toString(),	    
        onClose: this._dismissPanel	  
    });	 
  }

   private _dismissPanel() {	    
     this._renderPanelComponent({ isOpen: false });	
  }
  
  private _renderPanelComponent(props: any) {	    
    const element: React.ReactElement<ICustomPanelProps> = React.createElement(CustomPanel, assign({	      
      onClose: null,
      context:this.context,	      
      currentTitle: null,	   
      itemId: null,	     
      isOpen: false,	    
      listId: null	    
    }, props));	    
    ReactDom.render(element, this.panelPlaceHolder);	
   }	


  private panelPlaceHolder: HTMLDivElement = null;
  @override	  public onInit(): Promise<void> {	    
    Log.info(LOG_SOURCE, 'Initialized CommandSetWithPanelCommandSet');	    
    // // Setup the PnP JS with SPFx context	    
    // sp.setup({	      
    //   spfxContext: this.context	    
    // });	
    // // Create the container for our React component	   
     this.panelPlaceHolder = document.body.appendChild(document.createElement("div"));	    
     return Promise.resolve();	  
    }

  @override
  public onListViewUpdated(event: IListViewCommandSetListViewUpdatedParameters): void {
    const compareOneCommand: Command = this.tryGetCommand('COMMAND_1');
    if (compareOneCommand) {
      // This command should be hidden unless exactly one row is selected.
      //compareOneCommand.visible = event.selectedRows.length === 1;
      compareOneCommand.visible = event.selectedRows.length >= 1;
    }
  }

  @override
  public onExecute(event: IListViewCommandSetExecuteEventParameters): void {
    switch (event.itemId) {
      case 'COMMAND_1':
        // let selectedItem = event.selectedRows[0];	 
        let listItemId=[];
        let selectedItem = event.selectedRows.forEach(e => {
          listItemId.push(e.getValueByName('ID'));
        });		              
        //selectedItem.getValueByName('ID') as number;	        
        //const title = selectedItem.getValueByName("Title");	        
         this._showPanel(listItemId);	       
         break;	     
         
      // case 'COMMAND_2':
      //   Dialog.alert(`${this.properties.sampleTextTwo}`);
      //   break;
      default:
        throw new Error('Unknown command');
    }
  }
}
