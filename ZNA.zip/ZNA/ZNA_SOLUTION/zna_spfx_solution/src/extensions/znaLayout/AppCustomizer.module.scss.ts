/* tslint:disable */
require("./AppCustomizer.module.css");
const styles = {
  app: 'app_b3ff1732',
  top: 'top_b3ff1732',
  bottom: 'bottom_b3ff1732'
};

export default styles;
/* tslint:enable */