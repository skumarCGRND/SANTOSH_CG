import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseApplicationCustomizer,
  PlaceholderContent,
  PlaceholderName
} from '@microsoft/sp-application-base';
import { Dialog } from '@microsoft/sp-dialog';

import * as strings from 'ZnaLayoutApplicationCustomizerStrings';
import styles from './AppCustomizer.module.scss';
import { escape } from '@microsoft/sp-lodash-subset';
const LOG_SOURCE: string = 'ZnaLayoutApplicationCustomizer';

export interface IZnaLayoutApplicationCustomizerProperties {
  Top: string;
  Bottom: string;
  Logo: string;
  favicon:string;
}




/** A Custom Action which can be run during execution of a Client Side Application */
export default class ZnaLayoutApplicationCustomizer
  extends BaseApplicationCustomizer<IZnaLayoutApplicationCustomizerProperties> {

    // These have been added
    private _topPlaceholder: PlaceholderContent | undefined;
    private _bottomPlaceholder: PlaceholderContent | undefined;
    private _onDispose(): void {
      console.log('[ZnaLayoutApplicationCustomizer._onDispose] Disposed custom top and bottom placeholders.');
    }
    @override
    public onInit(): Promise<void> {
      this._renderPlaceHolders()
      //Savicon Start
      const SaviIconUrl: any = require("./Images/SaviIcon.png");
      //let SaviIconUrl: string = this.properties.favicon;      
      var link = document.querySelector("link[rel*='icon']") as HTMLElement || document.createElement('link') as HTMLElement;
      link.setAttribute('type', 'image/x-icon');
      link.setAttribute('rel', 'shortcut icon');
      link.setAttribute('href', SaviIconUrl);
      document.getElementsByTagName('head')[0].appendChild(link);   
    //favicon End
    return Promise.resolve();
  }
   private _renderPlaceHolders(): void { 
    
  const logoString: any = require("./Images/SiteLogo.png");
   const bottomString: any = "Copyright © 2020 Zurich American Insurance Company";

    console.log("HelloWorldApplicationCustomizer._renderPlaceHolders()");
    console.log(
        "Available placeholders: ",
        this.context.placeholderProvider.placeholderNames
            .map(name => PlaceholderName[name])
            .join(", ")
    );

    // Handling the top placeholder
    if (!this._topPlaceholder) {
        this._topPlaceholder = this.context.placeholderProvider.tryCreateContent(
            PlaceholderName.Top,
            { onDispose: this._onDispose }
        );

        // The extension should not assume that the expected placeholder is available.
        if (!this._topPlaceholder) {
            console.error("The expected placeholder (Top) was not found.");
            return;
        }

        if (this.properties) {
            // let topString: string = this.properties.Top;
            // if (!topString) {
            //     topString = "(Top property was not defined.)";
            // }

            // let logoString: string = this.properties.Logo;
            // if (!topString) {
            //   logoString = "(Top property was not defined.)";
            // }

            if (this._topPlaceholder.domElement) {
                this._topPlaceholder.domElement.innerHTML = `
                <div class="${styles.app}">
                    <div class="ms-bgColor-themeDark ms-fontColor-white ${styles.top}">
                        <div>
                            <a href="${this.context.pageContext.web.absoluteUrl}">
                              <img  src="${escape(logoString)}" alt="${escape(logoString)}" />
                            </a>
                        </div>
                    <div>
                </div>`;
            }
        }
      }

    // Handling the bottom placeholder
    if (!this._bottomPlaceholder) {
        this._bottomPlaceholder = this.context.placeholderProvider.tryCreateContent(
            PlaceholderName.Bottom,
            { onDispose: this._onDispose }
        );

        // The extension should not assume that the expected placeholder is available.
        if (!this._bottomPlaceholder) {
            console.error("The expected placeholder (Bottom) was not found.");
            return;
        }

        if (this.properties) {
            // let bottomString: string = this.properties.Bottom;
            // if (!bottomString) {
            //     bottomString = "(Bottom property was not defined.)";
            // }

            if (this._bottomPlaceholder.domElement) {
                this._bottomPlaceholder.domElement.innerHTML = `
                <div class="${styles.app}">
                    <div class="${styles.bottom}">
                        <i class="ms-Icon ms-Icon--Info" aria-hidden="true"></i> ${escape(
                            bottomString
                        )}
                    </div>
                </div>`;
            }
        }
    }
}
}
